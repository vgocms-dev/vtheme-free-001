import { Metadata } from 'next';
import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { getSiteVideos, getSiteTaxonomies, getSiteAds } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import VideoFilters from '@/components/video/VideoFilters';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import TaxonomyLoading from '../loading';
import { getImageUrl } from '@/lib/utils';

import { constructMetadata } from '@/lib/seo';

export async function generateMetadata(
  props: { params: Promise<{ slug: string }>, searchParams: Promise<{ [key: string]: string | string[] | undefined }> }
): Promise<Metadata> {
  const { slug } = await props.params;
  const sParams = await props.searchParams;

  const queryParams: Record<string, string | number> = { category: slug };
  ['page', 'limit', 'q', 'year', 'kind', 'country', 'sort', 'hot_period', 'tag', 'format', 'server', 'release_status', 'in_cinema'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const [videosRes, taxRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteTaxonomies().catch(() => null)
  ]);

  const seo = videosRes?.seo;
  const taxonomy = taxRes?.success ? taxRes.data?.category?.find(c => c.slug === slug) : null;
  const displayName = taxonomy?.display_name || slug;

  return constructMetadata(
    seo,
    `Phim thể loại: ${displayName} | Video Site`,
    `Tuyển tập phim ${displayName} mới nhất, cập nhật liên tục.`
  );
}

async function TheLoaiContent({
  slug,
  sParams
}: {
  slug: string;
  sParams: { [key: string]: string | string[] | undefined };
}) {
  const taxonomiesRes = await getSiteTaxonomies().catch(() => null);
  const taxonomyGroups = taxonomiesRes?.success ? taxonomiesRes.data : {};
  const taxonomy = taxonomyGroups?.category?.find(c => c.slug === slug) || null;

  if (!taxonomy) {
    notFound();
  }

  const queryParams: Record<string, string | number> = {
    category: slug,
  };

  ['page', 'limit', 'q', 'year', 'kind', 'country', 'sort', 'hot_period', 'tag', 'format', 'server', 'release_status', 'in_cinema'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const currentPage = parseInt(queryParams.page as string || '1');
  const [videosRes, adsRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteAds().catch(() => [])
  ]);
  const videosData = videosRes?.success ? videosRes.data : null;
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const currentUrl = `${siteUrl}/the-loai/${slug}${currentPage > 1 ? `?page=${currentPage}` : ''}`;

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": `${currentUrl}#webpage`,
        "url": currentUrl,
        "name": `Phim Thể Loại: ${taxonomy.display_name} - Trang ${currentPage}`,
        "description": `Tuyển tập phim ${taxonomy.display_name} mới nhất, cập nhật liên tục.`,
        "isPartOf": {
          "@id": `${siteUrl}/#website`
        },
        "breadcrumb": {
          "@id": `${currentUrl}#breadcrumb`
        }
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${currentUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "item": {
              "@id": `${siteUrl}/`,
              "name": "Trang Chủ"
            }
          },
          {
            "@type": "ListItem",
            "position": 2,
            "item": {
              "@id": `${siteUrl}/the-loai/${slug}`,
              "name": taxonomy.display_name
            }
          }
        ]
      },
      ...(videosData && videosData.items && videosData.items.length > 0 ? [{
        "@type": "ItemList",
        "@id": `${currentUrl}#itemlist`,
        "name": `Danh sách phim thể loại ${taxonomy.display_name}`,
        "itemListElement": videosData.items.map((video: any, index: number) => ({
          "@type": "ListItem",
          "position": index + 1,
          "item": {
            "@type": video.episode_count > 1 ? "TVSeries" : "Movie",
            "url": `${siteUrl}/phim/${video.slug}`,
            "name": video.title,
            "image": getImageUrl(video.thumb || video.poster),
            ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {}),
            ...(video.directors && video.directors.length > 0 ? {
              "director": video.directors.map((d: any) => ({
                "@type": "Person",
                "name": d.name
              }))
            } : {})
          }
        }))
      }] : [])
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
        Phim Thể Loại: {taxonomy.display_name}
      </h1>
      
      <VideoFilters
        categories={taxonomyGroups.category || []}
        countries={taxonomyGroups.country || []}
        servers={taxonomyGroups.server || []}
        formats={taxonomyGroups.format || []}
        kinds={taxonomyGroups.kind || []}
        currentCategory={slug}
      />

      <div>
        <AdSlot position="listing_top" ads={ads} />
      </div>

      {videosData && videosData.items && videosData.items.length > 0 ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 mt-6">
            {videosData.items.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={videosData.total_pages}
            basePath={`/the-loai/${slug}`}
            searchParams={sParams}
          />
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center mt-6">
          <p className="text-gray-500 text-lg">Chưa có phim nào trong thể loại này.</p>
        </div>
      )}

      <div>
        <AdSlot position="listing_bottom" ads={ads} />
      </div>
    </>
  );
}

export default async function TheLoaiPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { slug } = await params;
  const sParams = await searchParams;
  const suspenseKey = JSON.stringify(sParams);

  return (
    <Suspense key={suspenseKey} fallback={<TaxonomyLoading />}>
      <TheLoaiContent slug={slug} sParams={sParams} />
    </Suspense>
  );
}
