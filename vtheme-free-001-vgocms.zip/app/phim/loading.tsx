export default function ListLoading() {
  return (
    <div>
      <div className="h-9 w-64 skeleton rounded-lg mb-8"></div>
      
      {/* Filters Skeleton */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-10 skeleton rounded-lg"></div>
        ))}
      </div>

      {/* Videos Grid Skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="space-y-3">
            <div className="aspect-[2/3] skeleton rounded-lg"></div>
            <div className="h-4 w-3/4 skeleton rounded"></div>
          </div>
        ))}
      </div>
    </div>
  );
}
