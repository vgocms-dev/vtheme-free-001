import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getSiteVideoDetail, getSiteAds, getSiteRelatedVideos } from '@/lib/api';
import ClientVideo from './ClientVideo';

import { constructMetadata } from '@/lib/seo';
import { getImageUrl } from '@/lib/utils';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const res = await getSiteVideoDetail(slug).catch(() => null);

  if (!res?.success || !res.video) {
    return { title: 'Video not found' };
  }

  const { video, seo } = res;

  const images = [
    {
      url: getImageUrl(video.poster || video.thumb),
      alt: video.title,
    },
  ];

  return constructMetadata(
    seo,
    video.seo_title || video.title || 'Phim mới',
    video.seo_description || video.description || `Xem phim ${video.title} mới nhất.`,
    images,
    'video.movie'
  );
}

export default async function VideoDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  const [res, adsRes, relatedRes] = await Promise.all([
    getSiteVideoDetail(slug).catch(() => null),
    getSiteAds().catch(() => []),
    getSiteRelatedVideos(slug).catch(() => null)
  ]);

  if (!res?.success || !res.video) {
    notFound();
  }

  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);
  const relatedVideos = relatedRes?.success && relatedRes.data?.items ? relatedRes.data.items : [];

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const currentUrl = `${siteUrl}/phim/${slug}`;
  const video = res.video;
  const isSeries = (video.episode_count || 0) > 1;
  const movieType = isSeries ? "TVSeries" : "Movie";

  const directors = video.directors?.map((d: any) => ({
    "@type": "Person",
    "name": d.person?.name || d.name || d.role,
    "url": `${siteUrl}/dao-dien/${d.person?.slug || d.slug || ''}`
  })) || [{ "@type": "Person", "name": "Đang cập nhật..." }];

  const actors = video.actors?.map((a: any) => ({
    "@type": "Person",
    "name": a.person?.name || a.name || a.role,
    "url": `${siteUrl}/dien-vien/${a.person?.slug || a.slug || ''}`
  })) || [];

  const totalVotes = (video.likes || 0) + (video.dislikes || 0);
  const ratingValue = totalVotes > 0 ? ((video.likes / totalVotes) * 10).toFixed(1) : "9.5";
  const ratingCount = totalVotes > 0 ? totalVotes.toString() : "100";

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebPage",
        "@id": currentUrl,
        "url": currentUrl,
        "name": video.seo_title || video.title,
        "isPartOf": {
          "@id": `${siteUrl}/#website`
        },
        "primaryImageOfPage": {
          "@id": `${currentUrl}#primaryimage`
        },
        "image": {
          "@id": `${currentUrl}#primaryimage`
        },
        "thumbnailUrl": getImageUrl(video.thumb || video.poster),
        ...(video.created_at ? { "datePublished": new Date(video.created_at).toISOString() } : {}),
        ...(video.updated_at ? { "dateModified": new Date(video.updated_at).toISOString() } : {}),
        "description": video.seo_description || video.description,
        "breadcrumb": {
          "@id": `${currentUrl}#breadcrumb`
        },
        "inLanguage": "vi",
        "potentialAction": [
          {
            "@type": "ReadAction",
            "target": [currentUrl]
          }
        ]
      },
      {
        "@type": "ImageObject",
        "inLanguage": "vi",
        "@id": `${currentUrl}#primaryimage`,
        "url": getImageUrl(video.thumb || video.poster),
        "contentUrl": getImageUrl(video.thumb || video.poster),
        "width": 1200,
        "height": 630
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${currentUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Trang chủ",
            "item": siteUrl
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Phim",
            "item": `${siteUrl}/phim`
          },
          ...(video.kind ? [{
            "@type": "ListItem",
            "position": 3,
            "name": video.kind.name,
            "item": `${siteUrl}/kieu-phim/${video.kind.slug}`
          }] : []),
          {
            "@type": "ListItem",
            "position": video.kind ? 4 : 3,
            "name": video.title,
            "item": currentUrl
          }
        ]
      },
      {
        "@type": movieType,
        "name": video.title,
        "description": video.description,
        "image": getImageUrl(video.thumb || video.poster),
        ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {}),
        "director": directors.length === 1 ? directors[0] : directors,
        "actor": actors,
        "url": currentUrl,
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": ratingValue,
          "ratingCount": ratingCount,
          "bestRating": "10"
        }
      }
    ]
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4">
      <ClientVideo video={res.video} serverEpisodes={res.server_episodes} ads={ads} relatedVideos={relatedVideos} />

      {/* Schema.org JSON-LD cho SEO Video */}
      <script
        id="schema-json-ld"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />
    </div>
  );
}
