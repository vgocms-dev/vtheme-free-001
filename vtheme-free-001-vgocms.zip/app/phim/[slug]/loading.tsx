export default function VideoLoading() {
  return (
    <div className="max-w-7xl mx-auto py-6 px-4 space-y-8">
      {/* Player Section Skeleton */}
      <div className="bg-gray-950 -mx-4 sm:mx-0 sm:rounded-xl overflow-hidden shadow-2xl aspect-video skeleton"></div>

      {/* Episode List Skeleton */}
      <div className="mt-6">
        <div className="h-7 w-48 skeleton rounded-full mb-4"></div>
        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="h-10 skeleton rounded"></div>
          ))}
        </div>
      </div>

      {/* Video Details Skeleton */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 mt-8 border border-gray-100 dark:border-gray-700">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster Skeleton */}
          <div className="w-full max-w-[200px] md:w-1/4 md:max-w-[220px] shrink-0 mx-auto md:mx-0">
            <div className="aspect-[2/3] skeleton rounded-lg"></div>
            <div className="h-10 skeleton rounded-lg mt-4"></div>
            <div className="h-10 skeleton rounded-lg mt-3"></div>
          </div>

          {/* Info Skeleton */}
          <div className="w-full min-w-0 space-y-4">
            <div className="h-10 w-3/4 skeleton rounded-lg"></div>
            <div className="h-6 w-1/2 skeleton rounded"></div>

            <div className="flex gap-2">
              <div className="h-6 w-24 skeleton rounded"></div>
              <div className="h-6 w-24 skeleton rounded"></div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="flex gap-2">
                  <div className="h-4 w-20 skeleton rounded"></div>
                  <div className="h-4 w-32 skeleton rounded"></div>
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-4">
              <div className="h-6 w-32 skeleton rounded"></div>
              <div className="h-4 w-full skeleton rounded"></div>
              <div className="h-4 w-full skeleton rounded"></div>
              <div className="h-4 w-2/3 skeleton rounded"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
