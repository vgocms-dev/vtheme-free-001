import { Metadata } from 'next';
import { Suspense } from 'react';
import { getSiteVideos, getSiteTaxonomies, getSiteAds } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import VideoFilters from '@/components/video/VideoFilters';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import ListLoading from './loading';

import { constructMetadata } from '@/lib/seo';

export async function generateMetadata({ searchParams }: { searchParams: Promise<{ [key: string]: string | string[] | undefined }> }): Promise<Metadata> {
  const params = await searchParams;
  const queryParams: Record<string, string | number> = {};
  ['page', 'limit', 'q', 'year', 'kind', 'category', 'country', 'sort', 'hot_period', 'tag', 'format', 'server', 'release_status', 'in_cinema'].forEach(key => {
    if (params[key]) {
      queryParams[key] = params[key] as string;
    }
  });

  const videosRes = await getSiteVideos(queryParams).catch(() => null);
  const seo = videosRes?.seo;

  return constructMetadata(seo, 'Danh sách phim | Video Site', 'Khám phá hàng ngàn bộ phim hay, cập nhật liên tục.');
}

async function PhimContent({
  params
}: {
  params: { [key: string]: string | string[] | undefined };
}) {
  // Extract all valid filter parameters
  const queryParams: Record<string, string | number> = {};

  ['page', 'limit', 'q', 'year', 'kind', 'category', 'country', 'sort', 'hot_period', 'tag', 'format', 'server', 'release_status', 'in_cinema'].forEach(key => {
    if (params[key]) {
      queryParams[key] = params[key] as string;
    }
  });

  // Default to page 1 if not set
  const currentPage = parseInt(queryParams.page as string || '1');

  // Fetch data in parallel
  const [videosRes, taxonomiesRes, adsRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteTaxonomies().catch(() => null),
    getSiteAds().catch(() => [])
  ]);

  const videosData = videosRes?.success ? videosRes.data : null;
  const taxonomies = taxonomiesRes?.success ? taxonomiesRes.data : {};
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  return (
    <>
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
        Danh sách phim {params.q ? `tìm kiếm: "${params.q}"` : ''}
      </h1>

      {/* Schema.org JSON-LD cho CollectionPage */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": params.q ? "SearchResultsPage" : "CollectionPage",
            "name": `Danh sách phim ${params.q ? `tìm kiếm: "${params.q}"` : ''}`,
            "url": `${process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000'}/phim${params.q ? `?q=${params.q}` : ''}`,
            "mainEntity": {
              "@type": "ItemList",
              "itemListElement": videosData?.items?.map((video: any, index: number) => ({
                "@type": "ListItem",
                "position": index + 1,
                "url": `${process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000'}/phim/${video.slug}`
              })) || []
            }
          })
        }}
      />

      <VideoFilters
        categories={taxonomies.category || []}
        countries={taxonomies.country || []}
        servers={taxonomies.server || []}
        formats={taxonomies.format || []}
        kinds={taxonomies.kind || []}
      />

      <div>
        <AdSlot position="listing_top" ads={ads} />
      </div>

      {videosData && videosData.items && videosData.items.length > 0 ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {videosData.items.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={videosData.total_pages}
            basePath="/phim"
            searchParams={params}
          />
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center">
          <p className="text-gray-500 text-lg">Không tìm thấy phim nào phù hợp với bộ lọc của bạn.</p>
        </div>
      )}

      <div>
        <AdSlot position="listing_bottom" ads={ads} />
      </div>
    </>
  );
}

export default async function PhimPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  // Key based on all query params to trigger suspense on any filter/page change
  const suspenseKey = JSON.stringify(params);

  return (
    <Suspense key={suspenseKey} fallback={<ListLoading />}>
      <PhimContent params={params} />
    </Suspense>
  );
}
