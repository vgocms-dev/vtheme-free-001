import { getSiteVideos, getSiteStars } from '@/lib/api';


const sitemapBaseUrl = () => process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
const xmlEscape = (str: string) => str;

export async function GET() {
    try {
        const baseUrl = sitemapBaseUrl();
        const lastmod = new Date().toISOString();
        
        // Fetch total pages for movies (limit=500 per sitemap page)
        const videosRes = await getSiteVideos({ page: 1, limit: 500 }).catch(() => null);
        const starsRes = await getSiteStars('1', '', '').catch(() => null);
        
        const videoPages = videosRes?.success ? (videosRes.data.total_pages || 1) : 1;
        const starPages = starsRes?.success ? (starsRes.data.total_pages || 1) : 1;

        let items = '';
        
        for (let i = 1; i <= videoPages; i++) {
            items += `<sitemap><loc>${xmlEscape(`${baseUrl}/sitemap-phim/${i}.xml`)}</loc><lastmod>${lastmod}</lastmod></sitemap>`;
        }
        
        for (let i = 1; i <= starPages; i++) {
            items += `<sitemap><loc>${xmlEscape(`${baseUrl}/sitemap-ngoi-sao/${i}.xml`)}</loc><lastmod>${lastmod}</lastmod></sitemap>`;
        }
        
        items += `<sitemap><loc>${xmlEscape(`${baseUrl}/sitemap-the-loai.xml`)}</loc><lastmod>${lastmod}</lastmod></sitemap>`;

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${items}</sitemapindex>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml; charset=utf-8',
                'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=59',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap index', { status: 500 });
    }
}
