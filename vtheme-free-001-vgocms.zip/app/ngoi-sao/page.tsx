import { Metadata } from 'next';
import { Suspense } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { getSiteStars, getSiteAds } from '@/lib/api';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import { getImageUrl } from '@/lib/utils';
import StarFilterForm from '@/components/ui/StarFilterForm';
import PersonLoading from './loading';

import { constructMetadata } from '@/lib/seo';

export async function generateMetadata(): Promise<Metadata> {
    const res = await getSiteStars('1', '', '').catch(() => null);
    const seo = res?.seo;

    return constructMetadata(
        seo,
        'Ngôi Sao & Đạo Diễn',
        'Trang tổng hợp danh sách các diễn viên và đạo diễn tài năng với phim hay nhất',
        [],
        'website'
    );
}

async function StarsContent({
    params
}: {
    params: { [key: string]: string | string[] | undefined };
}) {
    const page = (params.page as string) || '1';
    const q = (params.q as string) || '';
    const role = (params.role as string) || '';

    const [res, adsRes] = await Promise.all([
        getSiteStars(page, q, role).catch(() => null),
        getSiteAds().catch(() => [])
    ]);

    const persons = res?.data?.items || [];
    const totalPages = res?.data?.total_pages || 1;
    const currentPage = parseInt(page);
    const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

    const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
    const currentUrl = `${siteUrl}/ngoi-sao${currentPage > 1 ? `?page=${currentPage}` : ''}`;

    const schemaData = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "CollectionPage",
                "@id": `${currentUrl}#webpage`,
                "url": currentUrl,
                "name": `Ngôi Sao & Đạo Diễn - Trang ${currentPage}`,
                "description": `Trang tổng hợp danh sách các diễn viên và đạo diễn tài năng.`,
                "isPartOf": {
                    "@id": `${siteUrl}/#website`
                },
                "breadcrumb": {
                    "@id": `${currentUrl}#breadcrumb`
                }
            },
            {
                "@type": "BreadcrumbList",
                "@id": `${currentUrl}#breadcrumb`,
                "itemListElement": [
                    {
                        "@type": "ListItem",
                        "position": 1,
                        "item": {
                            "@id": `${siteUrl}/`,
                            "name": "Trang Chủ"
                        }
                    },
                    {
                        "@type": "ListItem",
                        "position": 2,
                        "item": {
                            "@id": `${siteUrl}/ngoi-sao`,
                            "name": "Ngôi Sao"
                        }
                    }
                ]
            },
            ...(persons.length > 0 ? [{
                "@type": "ItemList",
                "@id": `${currentUrl}#itemlist`,
                "name": `Danh sách Ngôi Sao`,
                "itemListElement": persons.map((person: any, index: number) => ({
                    "@type": "ListItem",
                    "position": index + 1,
                    "item": {
                        "@type": "Person",
                        "url": `${siteUrl}/ngoi-sao/${person.slug}`,
                        "name": person.name,
                        "image": getImageUrl(person.avatar),
                        ...(person.created_at ? { "dateCreated": new Date(person.created_at).toISOString() } : {})
                    }
                }))
            }] : [])
        ]
    };

    return (
        <div className="space-y-8">
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
            />
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
                    Ngôi Sao
                </h1>

                <StarFilterForm defaultQ={q} defaultRole={role} />
            </div>

            {persons.length > 0 ? (
                <>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                        {persons.map((person: any, i: number) => (
                            <Link key={person.id} href={`/ngoi-sao/${person.slug}`} className="group block">
                                <div className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200">
                                    <div className="aspect-square relative flex justify-center items-center bg-gray-100 dark:bg-gray-700">
                                        {person.avatar ? (
                                            <Image
                                                src={getImageUrl(person.avatar)}
                                                alt={person.name}
                                                fill
                                                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 16vw"
                                                priority={i < 6}
                                                fetchPriority={i < 6 ? "high" : undefined}
                                                className="object-cover group-hover:scale-105 transition-transform duration-300"
                                            />
                                        ) : (
                                            <span className="text-4xl text-gray-400">{person.name.charAt(0)}</span>
                                        )}
                                    </div>
                                    <div className="p-3 text-center">
                                        <h3 className="font-semibold text-gray-900 dark:text-white truncate" title={person.name}>
                                            {person.name}
                                        </h3>
                                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                            {person.video_count} phim
                                        </p>
                                    </div>
                                </div>
                            </Link>
                        ))}
                    </div>

                    {totalPages > 1 && (
                        <Pagination
                            currentPage={currentPage}
                            totalPages={totalPages}
                            basePath="/ngoi-sao"
                            searchParams={params}
                        />
                    )}
                </>
            ) : (
                <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center">
                    <p className="text-gray-500 text-lg">Không tìm thấy người nào.</p>
                </div>
            )}

            <div>
                <AdSlot position="listing_bottom" ads={ads} />
            </div>
        </div>
    );
}

export default async function StarsPage({
    searchParams,
}: {
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
    const sParams = await searchParams;
    const suspenseKey = JSON.stringify(sParams);

    return (
        <Suspense key={suspenseKey} fallback={<PersonLoading />}>
            <StarsContent params={sParams} />
        </Suspense>
    );
}
