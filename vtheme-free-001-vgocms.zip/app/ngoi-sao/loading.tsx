export default function StarsLoading() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="h-8 w-48 skeleton rounded-lg"></div>
        <div className="h-10 w-full md:w-64 skeleton rounded-lg"></div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm">
            <div className="aspect-square skeleton"></div>
            <div className="p-3 space-y-2">
              <div className="h-4 w-3/4 mx-auto skeleton rounded"></div>
              <div className="h-3 w-1/2 mx-auto skeleton rounded"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
