import { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getPersonDetail, getSiteAds } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import { getImageUrl } from '@/lib/utils';

import { constructMetadata } from '@/lib/seo';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
    const { slug } = await params;
    const res = await getPersonDetail(slug).catch(() => null);

    if (!res?.success || !res.person) {
        return { title: 'Người không tồn tại' };
    }

    const { person, seo } = res;

    const images = person.avatar ? [{ url: getImageUrl(person.avatar) }] : [];

    return constructMetadata(
        seo,
        person.seo_title || `${person.name} | Video Site`,
        person.seo_description || person.description || `Thông tin và các phim của ${person.name}.`,
        images,
        'profile'
    );
}

export default async function PersonPage({
    params,
    searchParams,
}: {
    params: Promise<{ slug: string }>;
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
    const { slug } = await params;
    const sParams = await searchParams;

    const page = sParams.page || '1';
    const [res, adsRes] = await Promise.all([
        getPersonDetail(slug, page as string).catch(() => null),
        getSiteAds().catch(() => [])
    ]);

    if (!res?.success || !res.person) {
        notFound();
    }

    const { person, videos } = res;
    const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

    const totalPages = res.total_pages || 1;
    const currentPage = parseInt(page as string);

    const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
    const currentUrl = `${siteUrl}/ngoi-sao/${slug}${currentPage > 1 ? `?page=${currentPage}` : ''}`;

    const schemaData = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "ProfilePage",
                "@id": `${currentUrl}#webpage`,
                "url": currentUrl,
                "name": `${person.name} | Video Site`,
                "description": person.seo_description || person.description || `Thông tin và các phim của ${person.name}.`,
                "isPartOf": {
                    "@id": `${siteUrl}/#website`
                },
                "breadcrumb": {
                    "@id": `${currentUrl}#breadcrumb`
                },
                "mainEntity": {
                    "@type": "Person",
                    "@id": `${currentUrl}#person`,
                    "name": person.name,
                    ...(person.original_name ? { "alternateName": person.original_name } : {}),
                    ...(person.birth_year && person.birth_year > 0 ? { "birthDate": `${person.birth_year}` } : {}),
                    ...(person.nationality ? { "nationality": person.nationality } : {}),
                    ...(person.avatar ? { "image": getImageUrl(person.avatar) } : {}),
                    "description": person.bio || person.description || ""
                }
            },
            {
                "@type": "BreadcrumbList",
                "@id": `${currentUrl}#breadcrumb`,
                "itemListElement": [
                    {
                        "@type": "ListItem",
                        "position": 1,
                        "item": {
                            "@id": `${siteUrl}/`,
                            "name": "Trang Chủ"
                        }
                    },
                    {
                        "@type": "ListItem",
                        "position": 2,
                        "item": {
                            "@id": `${siteUrl}/ngoi-sao`,
                            "name": "Ngôi Sao"
                        }
                    },
                    {
                        "@type": "ListItem",
                        "position": 3,
                        "item": {
                            "@id": `${currentUrl}`,
                            "name": person.name
                        }
                    }
                ]
            },
            ...(videos && videos.length > 0 ? [{
                "@type": "ItemList",
                "@id": `${currentUrl}#itemlist`,
                "name": `Danh sách phim của ${person.name}`,
                "itemListElement": videos.map((video: any, index: number) => ({
                    "@type": "ListItem",
                    "position": index + 1,
                    "item": {
                        "@type": video.episode_count > 1 ? "TVSeries" : "Movie",
                        "url": `${siteUrl}/phim/${video.slug}`,
                        "name": video.title,
                        "image": getImageUrl(video.thumb || video.poster),
                        ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {}),
                        ...(video.directors && video.directors.length > 0 ? {
                          "director": video.directors.map((d: any) => ({
                            "@type": "Person",
                            "name": d.name
                          }))
                        } : {})
                    }
                }))
            }] : [])
        ]
    };

    return (
        <div className="space-y-8">
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
            />
            {/* Breadcrumb */}
            <nav className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1">
                <Link href="/ngoi-sao" className="hover:text-blue-500 transition-colors">Ngôi Sao</Link>
                <span>/</span>
                <span className="text-gray-700 dark:text-gray-300">{person.name}</span>
            </nav>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 flex flex-col sm:flex-row gap-6 items-start">
                {person.avatar ? (
                    <div className="relative w-32 h-32 sm:w-48 sm:h-48 rounded-full overflow-hidden shadow-md border-4 border-gray-100 dark:border-gray-700 mx-auto sm:mx-0 shrink-0">
                        <Image
                            src={getImageUrl(person.avatar)}
                            alt={person.name}
                            fill
                            sizes="(max-width: 640px) 128px, 192px"
                            className="object-cover"
                        />
                    </div>
                ) : (
                    <div className="w-32 h-32 sm:w-48 sm:h-48 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-400 text-4xl shadow-md mx-auto sm:mx-0 shrink-0">
                        {person.name?.charAt(0)}
                    </div>
                )}

                <div className="flex-1 text-center sm:text-left">
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{person.name}</h1>
                    <div className="flex flex-col gap-1 mb-4 text-sm text-gray-600 dark:text-gray-400">
                        {person.original_name && <p><strong>Tên gốc:</strong> {person.original_name}</p>}
                        {person.birth_year > 0 && <p><strong>Năm sinh:</strong> {person.birth_year}</p>}
                        {person.nationality && <p><strong>Quốc tịch:</strong> {person.nationality}</p>}
                    </div>

                    <div className="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-300">
                        {person.bio || person.description ? (
                            <div dangerouslySetInnerHTML={{ __html: person.bio || person.description }} />
                        ) : (
                            <p>Chưa có thông tin tiểu sử.</p>
                        )}
                    </div>
                </div>
            </div>

            <div>
                <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
                    Phim của {person.name}
                </h2>

                {videos && videos.length > 0 ? (
                    <>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                            {videos.map((video: any) => (
                                <VideoCard key={video.id} video={video} />
                            ))}
                        </div>

                        {totalPages > 1 && (
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                basePath={`/ngoi-sao/${slug}`}
                                searchParams={sParams as Record<string, string | string[] | undefined>}
                            />
                        )}
                    </>
                ) : (
                    <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center">
                        <p className="text-gray-500 text-lg">Chưa có phim nào của người này.</p>
                    </div>
                )}
            </div>

            <div>
                <AdSlot position="listing_bottom" ads={ads} />
            </div>
        </div>
    );
}
