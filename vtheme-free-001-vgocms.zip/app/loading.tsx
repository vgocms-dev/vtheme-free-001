export default function HomeLoading() {
  return (
    <div className="space-y-12">
      {/* Top Phim Hot Tuần Skeleton */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <div className="h-8 w-48 skeleton rounded-lg"></div>
          <div className="h-4 w-24 skeleton rounded"></div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="aspect-[2/3] skeleton rounded-xl"></div>
          ))}
        </div>
      </section>

      {/* Phim Mới Nhất Skeleton */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <div className="h-8 w-48 skeleton rounded-lg"></div>
          <div className="h-4 w-24 skeleton rounded"></div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="space-y-3">
              <div className="aspect-[2/3] skeleton rounded-lg"></div>
              <div className="h-4 w-3/4 skeleton rounded"></div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
