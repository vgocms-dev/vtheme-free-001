import { getSiteVideos } from '@/lib/api';

const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET() {
    try {
        const videosRes = await getSiteVideos({ limit: 5000 }).catch(() => null);
        const videos = videosRes?.success ? videosRes.data.items : [];

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>${baseUrl}/phim</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    ${videos.map((video) => `
    <url>
        <loc>${baseUrl}/phim/${video.slug}</loc>
        <lastmod>${video.updated_at ? new Date(video.updated_at).toISOString() : new Date().toISOString()}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>`).join('')}
</urlset>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml',
                'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=59',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap', { status: 500 });
    }
}
