import { getSiteStars } from '@/lib/api';

const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET() {
    try {
        const starsRes = await getSiteStars('1', '', '').catch(() => null);
        const stars = starsRes?.success ? starsRes.data.items : [];

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>${baseUrl}/ngoi-sao</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.7</priority>
    </url>
    ${stars.map((star: any) => `
    <url>
        <loc>${baseUrl}/ngoi-sao/${star.slug}</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.5</priority>
    </url>`).join('')}
</urlset>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml',
                'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=3600',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap', { status: 500 });
    }
}
