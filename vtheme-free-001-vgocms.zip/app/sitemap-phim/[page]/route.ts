import { getSiteVideos } from '@/lib/api';

const PAGE_LIMIT = 500;
const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET(request: Request, context: { params: Promise<{ page: string }> }) {
    try {
        const { page: pageParam } = await context.params;
        const pageNum = parseInt(pageParam.replace('.xml', ''), 10) || 1;
        
        const res = await getSiteVideos({ page: pageNum, limit: PAGE_LIMIT }).catch(() => null);
        const videos: any[] = res?.success ? (res.data.items || []) : [];
        
        const children = videos.map((video) => `
    <url>
        <loc>${baseUrl}/phim/${video.slug}</loc>
        <lastmod>${video.updated_at ? new Date(video.updated_at).toISOString() : new Date().toISOString()}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>`).join('');

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${children}
</urlset>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml; charset=utf-8',
                'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=59',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap', { status: 500 });
    }
}
