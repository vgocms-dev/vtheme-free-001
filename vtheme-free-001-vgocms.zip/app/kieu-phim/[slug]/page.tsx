import { Metadata } from 'next';
import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { getSiteVideos, getSiteTaxonomies, getSiteAds } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import TaxonomyLoading from '../loading';

import { constructMetadata } from '@/lib/seo';
import { getImageUrl } from '@/lib/utils';

export async function generateMetadata(
  props: { params: Promise<{ slug: string }>, searchParams: Promise<{ [key: string]: string | string[] | undefined }> }
): Promise<Metadata> {
  const { slug } = await props.params;
  const sParams = await props.searchParams;

  const queryParams: Record<string, string | number> = { kind: slug };
  ['page', 'limit', 'sort'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const [videosRes, taxRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteTaxonomies('kind').catch(() => null)
  ]);

  const seo = videosRes?.seo;
  const taxonomy = taxRes?.success ? taxRes.data?.kind?.find(c => c.slug === slug) : null;
  const displayName = taxonomy?.display_name || slug;

  return constructMetadata(
    seo,
    `Kiểu phim: ${displayName} | Video Site`,
    `Tuyển tập phim ${displayName} mới nhất, cập nhật liên tục.`
  );
}

async function KieuPhimContent({
  slug,
  sParams
}: {
  slug: string;
  sParams: { [key: string]: string | string[] | undefined };
}) {
  const taxRes = await getSiteTaxonomies('kind').catch(() => null);
  const taxonomy = taxRes?.success ? taxRes.data?.kind?.find(c => c.slug === slug) : null;

  if (!taxonomy) {
    notFound();
  }

  const queryParams: Record<string, string | number> = {
    kind: slug,
  };

  ['page', 'limit', 'sort'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const currentPage = parseInt(queryParams.page as string || '1');
  const [videosRes, adsRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteAds().catch(() => [])
  ]);
  const videosData = videosRes?.success ? videosRes.data : null;
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const currentUrl = `${siteUrl}/kieu-phim/${slug}${currentPage > 1 ? `?page=${currentPage}` : ''}`;

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": `${currentUrl}#webpage`,
        "url": currentUrl,
        "name": `Kiểu Phim: ${taxonomy.display_name} - Trang ${currentPage}`,
        "description": `Tuyển tập phim ${taxonomy.display_name} mới nhất, cập nhật liên tục.`,
        "isPartOf": {
          "@id": `${siteUrl}/#website`
        },
        "breadcrumb": {
          "@id": `${currentUrl}#breadcrumb`
        }
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${currentUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "item": {
              "@id": `${siteUrl}/`,
              "name": "Trang Chủ"
            }
          },
          {
            "@type": "ListItem",
            "position": 2,
            "item": {
              "@id": `${siteUrl}/kieu-phim/${slug}`,
              "name": taxonomy.display_name
            }
          }
        ]
      },
      ...(videosData && videosData.items && videosData.items.length > 0 ? [{
        "@type": "ItemList",
        "@id": `${currentUrl}#itemlist`,
        "name": `Danh sách phim kiểu ${taxonomy.display_name}`,
        "itemListElement": videosData.items.map((video: any, index: number) => ({
          "@type": "ListItem",
          "position": index + 1,
          "item": {
            "@type": video.episode_count > 1 ? "TVSeries" : "Movie",
            "url": `${siteUrl}/phim/${video.slug}`,
            "name": video.title,
            "image": getImageUrl(video.thumb || video.poster),
            ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {})
          }
        }))
      }] : [])
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
        Kiểu Phim: {taxonomy.display_name}
      </h1>

      <div>
        <AdSlot position="listing_top" ads={ads} />
      </div>

      {videosData && videosData.items && videosData.items.length > 0 ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {videosData.items.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={videosData.total_pages}
            basePath={`/kieu-phim/${slug}`}
            searchParams={sParams}
          />
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center">
          <p className="text-gray-500 text-lg">Chưa có phim nào thuộc kiểu phim này.</p>
        </div>
      )}

      <div>
        <AdSlot position="listing_bottom" ads={ads} />
      </div>
    </>
  );
}

export default async function KieuPhimPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { slug } = await params;
  const sParams = await searchParams;
  const suspenseKey = JSON.stringify(sParams);

  return (
    <Suspense key={suspenseKey} fallback={<TaxonomyLoading />}>
      <KieuPhimContent slug={slug} sParams={sParams} />
    </Suspense>
  );
}
