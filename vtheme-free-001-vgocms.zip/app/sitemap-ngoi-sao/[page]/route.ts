import { getSiteStars } from '@/lib/api';

const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET(request: Request, context: { params: Promise<{ page: string }> }) {
    try {
        const { page: pageParam } = await context.params;
        const pageNum = parseInt(pageParam.replace('.xml', ''), 10) || 1;
        
        const res = await getSiteStars(String(pageNum), '', '').catch(() => null);
        const stars: any[] = res?.success ? (res.data.items || []) : [];
        
        const children = stars.map((star: any) => `
    <url>
        <loc>${baseUrl}/ngoi-sao/${star.slug}</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.5</priority>
    </url>`).join('');

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${children}
</urlset>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml; charset=utf-8',
                'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=3600',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap', { status: 500 });
    }
}
