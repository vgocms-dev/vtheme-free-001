import { getSiteTaxonomies } from '@/lib/api';

const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET() {
    try {
        const taxonomiesRes = await getSiteTaxonomies().catch(() => null);
        const taxonomies = taxonomiesRes?.success ? taxonomiesRes.data : {};
        const { category, country, kind } = taxonomies as any;

        const urls: string[] = [];

        const addTax = (items: any[] | undefined, prefix: string, priority: number) => {
            if (!items) return;
            items.forEach((item) => {
                urls.push(`
    <url>
        <loc>${baseUrl}/${prefix}/${item.slug}</loc>
        <lastmod>${new Date().toISOString()}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>${priority}</priority>
    </url>`);
            });
        };

        addTax(category, 'the-loai', 0.7);
        addTax(country, 'quoc-gia', 0.6);
        addTax(kind, 'kieu-phim', 0.6);

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${urls.join('')}
</urlset>`;

        return new Response(xml, {
            headers: {
                'Content-Type': 'application/xml',
                'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=3600',
            },
        });
    } catch (error) {
        return new Response('Error generating sitemap', { status: 500 });
    }
}
