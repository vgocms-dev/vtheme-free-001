import Link from 'next/link';
import { Suspense } from 'react';
import { getSiteSettings, getSiteVideos, getSiteAds, getSiteTopViews } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import VideoCardHot from '@/components/video/VideoCardHot';
import AdSlot from '@/components/layout/AdSlot';
import { getImageUrl } from '@/lib/utils';
import HomeLoading from './loading';

export const revalidate = 300; // 5 minutes

async function HomeContent() {
  const [settingsRes, topViewsRes, mostViewedVideosRes, latestVideosRes, topRatedVideosRes, releasingVideosRes, adsRes] =
    await Promise.all([
      getSiteSettings().catch(() => null),
      getSiteTopViews().catch(() => null),
      getSiteVideos({ sort: 'view', limit: 10 }).catch(() => null),
      getSiteVideos({ sort: 'latest', limit: 10 }).catch(() => null),
      getSiteVideos({ sort: 'likes', limit: 10 }).catch(() => null),
      getSiteVideos({ release_status: 'releasing', limit: 10 }).catch(() => null),
      getSiteAds().catch(() => []),
    ]);

  const settings = settingsRes?.success ? settingsRes.data : null;
  const hotVideos = topViewsRes?.success ? (topViewsRes.data.week?.items || []) : [];
  const mostViewedVideos = mostViewedVideosRes?.success ? mostViewedVideosRes.data.items : [];
  const latestVideos = latestVideosRes?.success ? latestVideosRes.data.items : [];
  const topRatedVideos = topRatedVideosRes?.success ? topRatedVideosRes.data.items : [];
  const releasingVideos = releasingVideosRes?.success ? releasingVideosRes.data.items : [];
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const siteName = settings?.name || 'Motchill Phim Online';
  const siteDescription = settings?.seo_description || settings?.description || 'Motchill | Mọt Phim Hay | Phim Mới | HD Vietsub | Xem Phim Online';

  const allHomeVideos = [...hotVideos, ...latestVideos, ...releasingVideos, ...mostViewedVideos, ...topRatedVideos];
  const uniqueHomeVideosMap = new Map();
  allHomeVideos.forEach((v: any) => {
    if (v && v.id && !uniqueHomeVideosMap.has(v.id)) {
      uniqueHomeVideosMap.set(v.id, v);
    }
  });
  const uniqueHomeVideos = Array.from(uniqueHomeVideosMap.values()).slice(0, 20);

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": `${siteUrl}/#website`,
        "url": `${siteUrl}/`,
        "name": siteName,
        "description": siteDescription,
        "publisher": {
          "@id": `${siteUrl}/#organization`
        },
        "alternateName": siteName,
        "potentialAction": [
          {
            "@type": "SearchAction",
            "target": {
              "@type": "EntryPoint",
              "urlTemplate": `${siteUrl}/tim-kiem?keyword={search_term_string}`
            },
            "query-input": {
              "@type": "PropertyValueSpecification",
              "valueRequired": true,
              "valueName": "search_term_string"
            }
          }
        ],
        "inLanguage": "vi"
      },
      {
        "@type": "Organization",
        "@id": `${siteUrl}/#organization`,
        "name": siteName,
        "alternateName": siteName,
        "url": `${siteUrl}/`,
        ...(settings?.logo_url ? {
          "logo": {
            "@type": "ImageObject",
            "inLanguage": "vi",
            "@id": `${siteUrl}/#/schema/logo/image/`,
            "url": settings.logo_url,
            "contentUrl": settings.logo_url,
            "caption": siteName
          },
          "image": {
            "@id": `${siteUrl}/#/schema/logo/image/`
          }
        } : {})
      },
      ...(uniqueHomeVideos.length > 0 ? [{
        "@type": "ItemList",
        "name": "Danh sách phim nổi bật",
        "url": `${siteUrl}/`,
        "itemListElement": uniqueHomeVideos.map((v: any, i: number) => ({
          "@type": "ListItem",
          "position": i + 1,
          "item": {
            "@type": v.episode_count > 1 ? "TVSeries" : "Movie",
            "url": `${siteUrl}/phim/${v.slug}`,
            "name": v.title,
            "image": getImageUrl(v.thumb || v.poster),
            ...(v.created_at ? { "dateCreated": new Date(v.created_at).toISOString() } : {}),
            ...(v.directors && v.directors.length > 0 ? {
              "director": v.directors.map((d: any) => ({
                "@type": "Person",
                "name": d.name
              }))
            } : {})
          }
        }))
      }] : [])
    ]
  };

  return (
    <div className="space-y-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />

      {hotVideos.length > 0 && (
        <section>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-orange-700 pl-3 flex items-center gap-2">
              Top Phim Hot Tuần
            </h2>
            <Link
              href="/phim?hot_period=week"
              className="text-orange-800 hover:text-orange-900 text-sm font-semibold"
              aria-label="Xem tất cả phim hot tuần"
            >
              Xem tất cả &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
            {hotVideos.map((v, i) => (
              <VideoCardHot key={v.id} video={v} rank={i + 1} priority={i < 5} />
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-red-500 pl-3">
            Phim Mới Nhất
          </h2>
          <Link
            href="/phim?sort=latest"
            className="text-red-800 hover:text-red-900 text-sm font-semibold"
            aria-label="Xem tất cả phim mới nhất"
          >
            Xem tất cả &rarr;
          </Link>
        </div>

        {latestVideos.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {latestVideos.map((v, i) => (
              <VideoCard key={v.id} video={v} priority={i < 2} />
            ))}
          </div>
        ) : (
          <p className="text-gray-500">Chưa có dữ liệu phim mới.</p>
        )}
      </section>

      {releasingVideos.length > 0 && (
        <section>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-emerald-500 pl-3">
              Phim Đang Chiếu
            </h2>
            <Link href="/phim?release_status=releasing" className="text-emerald-500 hover:text-emerald-600 text-sm font-medium">
              Xem tất cả &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {releasingVideos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        </section>
      )}


      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
            Phim Xem Nhiều
          </h2>
          <Link
            href="/phim?sort=view"
            className="text-blue-800 hover:text-blue-900 text-sm font-semibold"
            aria-label="Xem tất cả phim xem nhiều"
          >
            Xem tất cả &rarr;
          </Link>
        </div>

        {mostViewedVideos.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {mostViewedVideos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <p className="text-gray-500">Chưa có dữ liệu phim xem nhiều.</p>
        )}
      </section>

      <div>
        <AdSlot position="home_featured" ads={ads} />
      </div>

      <div>
        <AdSlot position="home_middle" ads={ads} />
      </div>

      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white border-l-4 border-green-500 pl-3">
            Phim Đánh Giá Cao
          </h2>
          <Link
            href="/phim?sort=likes"
            className="text-green-800 hover:text-green-900 text-sm font-semibold"
            aria-label="Xem tất cả phim đánh giá cao"
          >
            Xem tất cả &rarr;
          </Link>
        </div>

        {topRatedVideos.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {topRatedVideos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <p className="text-gray-500">Chưa có dữ liệu đánh giá phim.</p>
        )}
      </section>
    </div>
  );
}

export default async function Home() {
  return (
    <Suspense fallback={<HomeLoading />}>
      <HomeContent />
    </Suspense>
  );
}
