/**
 * Chuẩn hóa URL ảnh poster/thumb/avatar từ API
 */
export function getImageUrl(src: string | undefined | null, baseUrl?: string): string {
  if (!src?.trim()) return '/placeholder-poster.jpg';
  const s = src.trim();
  if (s.startsWith('http://') || s.startsWith('https://')) return s;
  return `${baseUrl || process.env.NEXT_PUBLIC_API_BASE_URL || ''}${s}`;
}

export function getTmdbUrl(tmdbId: string | undefined): string {
  if (!tmdbId?.trim()) return '';
  const m = tmdbId.trim().match(/^(movie|tv):(\d+)$/i);
  if (m) {
    return `https://www.themoviedb.org/${m[1]}/${m[2]}`;
  }
  const num = tmdbId.replace(/\D/g, '');
  if (num) return `https://www.themoviedb.org/movie/${num}`;
  return `https://www.themoviedb.org/movie/${tmdbId}`;
}

export function naturalCompare(a: string, b: string): number {
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
}
