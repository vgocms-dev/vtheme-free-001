export interface SeoData {
  title: string;
  description: string;
  keywords: string;
  og_title: string;
  og_image: string;
  og_description: string;
  og_type: string;
  twitter_card: string;
}

export interface SiteSettings {
  name: string;
  domain: string;
  logo_url: string;
  favicon_url: string;
  description: string;
  seo_title: string; // @deprecated
  seo_description: string; // @deprecated
  seo_keywords: string; // @deprecated
  ga_code?: string;
  custom_head_html?: string;
  custom_body_html?: string;
  seo?: SeoData;
}

export interface VideoItem {
  id: number;
  title: string;
  original_name: string;
  slug: string;
  thumb: string;
  poster: string;
  year: number;
  views: number;
  site_status?: string;
  ai_status?: string;
  categories?: Taxonomy[];
  countries?: Taxonomy[];
  formats?: Taxonomy[];
  kind?: Taxonomy;
  /** Tập hiện tại / tổng số tập. Nếu episode_count=0 là phim lẻ */
  current_episode?: number;
  episode_count?: number;
  /** Trạng thái: releasing | completed | upcoming */
  release_status?: string;
  in_cinema?: boolean;
  created_at?: string;
  updated_at?: string;
  directors?: any[];
}

export interface VideoTag {
  id: number;
  name: string;
  slug: string;
}

export interface EpisodeInput {
  name: string;
  slug: string;
  link_m3u8: string;
  link_embed: string;
  thumb?: string;
}

export type EpisodePlaySource = 'embed' | 'hls';

export interface ServerEpisode {
  server_name: string;
  server_id: string;
  server_data: EpisodeInput[];
}

export interface Taxonomy {
  id: number;
  name: string;
  slug: string;
  type: string;
  lang_name?: string;
}

export interface VideoDetail {
  id: number;
  title: string;
  original_name: string;
  slug: string;
  description: string;
  thumb: string;
  poster: string;
  year: number;
  views: number;
  likes: number;
  dislikes: number;
  seo_title: string;
  seo_description: string;
  seo_keywords: string;
  kind?: Taxonomy;
  categories?: Taxonomy[];
  countries?: Taxonomy[];
  formats?: Taxonomy[];
  tags?: VideoTag[];
  actors?: { id?: number; name: string; slug: string; avatar?: string; role?: string }[];
  directors?: { id?: number; name: string; slug: string; avatar?: string; role?: string }[];
  video_actors?: any[];
  video_directors?: any[];
  /** Trạng thái: releasing | completed | upcoming */
  release_status?: string;
  in_cinema?: boolean;
  trailer_url?: string;
  avg_duration?: number;
  episode_count?: number;
  current_episode?: number;
  tmdb_id?: string;
  imdb_id?: string;
  created_at?: string;
  updated_at?: string;
}

export interface VideoDetailResponse {
  success: boolean;
  video: VideoDetail;
  server_episodes: ServerEpisode[];
  seo?: SeoData;
}

export interface MenuItem {
  id: number;
  label: string;
  url: string;
  target: '_self' | '_blank';
  icon?: string;
  children?: MenuItem[];
}

export interface MenuResponse {
  id: number;
  name: string;
  slug: string;
  items: MenuItem[];
}

export interface TaxonomyItem {
  id: number;
  name: string;
  slug: string;
  type: string;
  display_name: string;
}

export interface TaxonomyGroups {
  category?: TaxonomyItem[];
  country?: TaxonomyItem[];
  server?: TaxonomyItem[];
  format?: TaxonomyItem[];
  kind?: TaxonomyItem[];
}

export interface VideoListResponse {
  success: boolean;
  data: {
    items: VideoItem[];
    total_records: number;
    page: number;
    total_pages: number;
    limit: number;
  };
  seo?: SeoData;
}

export interface HotVideoResult {
  video_id: number;
  title: string;
  slug: string;
  thumb: string;
  poster: string;
  total_views: number;
}
