export const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
export const SITE_SLUG = process.env.NEXT_PUBLIC_SITE_SLUG || 'default-site';
export const MENU_HEADER_SLUG = process.env.NEXT_PUBLIC_MENU_HEADER_SLUG || 'header';
export const MENU_FOOTER_SLUG = process.env.NEXT_PUBLIC_MENU_FOOTER_SLUG || 'footer';
