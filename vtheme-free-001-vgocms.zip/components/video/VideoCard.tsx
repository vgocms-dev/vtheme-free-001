import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';

export default function VideoCard({ video, priority }: { video: VideoItem; priority?: boolean }) {
  const imgSrc = getImageUrl(video.poster || video.thumb);
  return (
    <Link
      href={`/phim/${video.slug}`}
      className="group block rounded-lg overflow-hidden shadow-md transition-transform hover:-translate-y-1 hover:shadow-xl"
    >
      {/* Image area - rounded, có nền */}
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-lg bg-white dark:bg-gray-800">
        <Image
          src={imgSrc}
          alt={video.title}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, (max-width: 1536px) 20vw, 15vw"
          quality={75}
          priority={priority}
          fetchPriority={priority ? "high" : undefined}
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-3">
          <div className="absolute top-2 right-2 flex flex-col items-end gap-1">
            {(video.episode_count ?? 0) > 0 && (
              <span className="bg-blue-600/90 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm">
                {video.current_episode ?? 0}/{video.episode_count ?? 0}
              </span>
            )}
            {video.formats && video.formats.length > 0 && (
              <span className="bg-yellow-500 text-yellow-950 text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm uppercase tracking-wide">
                {video.formats[0].lang_name || video.formats[0].name}
              </span>
            )}
          </div>

          {/* Metadata row: Kind • Country • Category - Phải sang trái, dưới lên trên */}
          <div className="flex flex-row-reverse flex-wrap-reverse items-center text-[11px] text-gray-300 font-medium gap-y-1 mt-0.5 w-full">
            {video.categories && video.categories.map((cat, idx) => (
              <React.Fragment key={`cat-${cat.id}`}>
                <span className="whitespace-nowrap hover:text-white transition-colors">
                  {cat.lang_name || cat.name}
                </span>
                {idx < (video.categories?.length || 0) - 1 && <span className="text-gray-600 mx-1">•</span>}
                {idx === (video.categories?.length || 0) - 1 && ((video.countries?.length || 0) > 0 || video.kind) && (
                  <span className="text-gray-600 mx-1">•</span>
                )}
              </React.Fragment>
            ))}

            {video.countries && video.countries.map((country, idx) => (
              <React.Fragment key={`country-${country.id}`}>
                <span className="whitespace-nowrap hover:text-white transition-colors">
                  {country.lang_name || country.name}
                </span>
                {idx < (video.countries?.length || 0) - 1 && <span className="text-gray-600 mx-1">•</span>}
                {idx === (video.countries?.length || 0) - 1 && video.kind && (
                  <span className="text-gray-600 mx-1">•</span>
                )}
              </React.Fragment>
            ))}

            {video.kind && (
              <span className="text-blue-400 whitespace-nowrap">
                {video.kind.lang_name || video.kind.name}
              </span>
            )}
          </div>

          {/* Views */}
          <div className="flex items-center text-gray-400 text-[11px] mt-1">
            <span className="flex items-center gap-1">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                <path
                  fillRule="evenodd"
                  d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z"
                  clipRule="evenodd"
                />
              </svg>
              {video.views?.toLocaleString() || 0} lượt xem
            </span>
          </div>
        </div>
      </div>

      {/* Chỉ Title & Original name dưới hình - không cắt, không nền */}
      <div className="px-1 py-1.5 bg-transparent">
        <h3 className="text-gray-900 dark:text-white font-semibold text-sm leading-snug">
          {video.title}
          {video.year > 0 && (
            <span className="text-gray-700 dark:text-gray-400 font-medium text-xs ml-0.5">
              ({video.year})
            </span>
          )}
        </h3>
      </div>
    </Link>
  );
}
