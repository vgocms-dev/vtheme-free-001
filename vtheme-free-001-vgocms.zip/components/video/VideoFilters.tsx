'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useState, useRef, useEffect } from 'react';
import { TaxonomyItem } from '@/lib/types';
import { SlidersHorizontal, X, ArrowDownAZ, ChevronDown } from 'lucide-react';

interface VideoFiltersProps {
  categories: TaxonomyItem[];
  countries: TaxonomyItem[];
  servers: TaxonomyItem[];
  formats: TaxonomyItem[];
  kinds: TaxonomyItem[];
  currentCategory?: string;
  currentCountry?: string;
  currentKind?: string;
  currentFormat?: string;
}

const RELEASE_OPTIONS = [
  { value: '', label: 'Tất cả' },
  { value: 'releasing', label: 'Đang phát hành' },
  { value: 'completed', label: 'Hoàn thành' },
  { value: 'upcoming', label: 'Chưa ra mắt' },
] as const;

const CINEMA_OPTIONS = [
  { value: '', label: 'Tất cả' },
  { value: '1', label: 'Chiếu rạp' },
] as const;

const SORT_OPTIONS = [
  { value: '', label: 'Mới nhất' },
  { value: 'hot_day', label: 'Hot ngày' },
  { value: 'hot_week', label: 'Hot tuần' },
  { value: 'hot_month', label: 'Hot tháng' },
  { value: 'view', label: 'Xem nhiều nhất' },
  { value: 'year', label: 'Năm mới nhất' },
  { value: 'likes', label: 'Đánh giá cao' },
] as const;

type OptionItem = { value: string; label: string };

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 ${active
        ? 'bg-blue-700 text-white shadow-md shadow-blue-600/25'
        : 'bg-gray-100 dark:bg-gray-700/80 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
        }`}
    >
      {children}
    </button>
  );
}

function CustomSelect({
  id,
  label,
  value,
  options,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  options: OptionItem[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const displayLabel = options.find((o) => o.value === value)?.label || 'Tất cả';

  return (
    <div
      ref={ref}
      className={`relative flex flex-col gap-1 min-w-0 flex-1 min-[400px]:flex-initial ${open ? 'z-[110]' : ''}`}
    >
      {label && (
        <label htmlFor={id} className="text-xs font-medium text-gray-500 dark:text-gray-400 truncate">
          {label}
        </label>
      )}
      <button
        type="button"
        id={id}
        onClick={() => setOpen(!open)}
        className="h-9 w-full min-w-[100px] px-3 pr-9 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-gray-100 text-left flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all hover:border-gray-300 dark:hover:border-gray-500 cursor-pointer shadow-sm"
      >
        <span className="truncate">{displayLabel}</span>
        <ChevronDown
          className={`w-4 h-4 text-gray-400 flex-shrink-0 ml-2 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
        />
      </button>
      {open && (
        <ul
          className="absolute left-0 right-0 top-full mt-1 z-[100] py-1.5 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 shadow-lg max-h-56 overflow-y-auto"
          role="listbox"
        >
          {options.map((o) => (
            <li key={o.value} role="option" aria-selected={value === o.value}>
              <button
                type="button"
                onClick={() => {
                  onChange(o.value);
                  setOpen(false);
                }}
                className={`w-full px-3 py-2 text-left text-sm flex items-center gap-2 transition-colors ${value === o.value
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-600 font-medium'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60'
                  }`}
              >
                {value === o.value && (
                  <span className="w-1 h-4 rounded-full bg-blue-500 shrink-0" />
                )}
                <span className="truncate">{o.label}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function SelectFilter({
  id,
  label,
  value,
  onChange,
  options,
  optionList,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  options?: OptionItem[];
  optionList?: TaxonomyItem[];
}) {
  const opts: OptionItem[] = optionList
    ? [{ value: '', label: 'Tất cả' }, ...optionList.map((o) => ({ value: o.slug, label: o.display_name }))]
    : options || [];
  return <CustomSelect id={id} label={label} value={value} options={opts} onChange={onChange} />;
}

export default function VideoFilters({
  categories, countries, servers, formats, kinds,
  currentCategory, currentCountry, currentKind, currentFormat
}: VideoFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const hasAdvancedFilters = !!getParam('kind') || !!getParam('category') || !!getParam('country') || !!getParam('year') || !!getParam('format');
    if (hasAdvancedFilters) {
      setExpanded(true);
    }
  }, []);

  const getParam = (key: string) => {
    const val = searchParams.get(key);
    if (val) return val;
    if (key === 'category' && currentCategory) return currentCategory;
    if (key === 'country' && currentCountry) return currentCountry;
    if (key === 'kind' && currentKind) return currentKind;
    if (key === 'format' && currentFormat) return currentFormat;
    return '';
  };

  const syncParams = (params: URLSearchParams) => {
    if (currentCategory && !params.has('category')) params.set('category', currentCategory);
    if (currentCountry && !params.has('country')) params.set('country', currentCountry);
    if (currentKind && !params.has('kind')) params.set('kind', currentKind);
    if (currentFormat && !params.has('format')) params.set('format', currentFormat);
    return params;
  }

  const handleFilterChange = (key: string, value: string) => {
    let params = new URLSearchParams(searchParams.toString());
    params = syncParams(params);
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.set('page', '1');
    router.push(`/phim?${params.toString()}`);
  };


  const handleSortChange = (value: string) => {
    let params = new URLSearchParams(searchParams.toString());
    params = syncParams(params);
    params.delete('sort');
    params.delete('hot_period');
    const hotPeriodMap: Record<string, string> = {
      hot_day: 'day',
      hot_week: 'week',
      hot_month: 'month',
    };
    if (hotPeriodMap[value]) {
      params.set('hot_period', hotPeriodMap[value]);
    } else if (value) {
      params.set('sort', value);
    }
    params.set('page', '1');
    router.push(`/phim?${params.toString()}`);
  };

  const hotPeriodToSort: Record<string, string> = {
    day: 'hot_day',
    week: 'hot_week',
    month: 'hot_month',
  };
  const sortValue = hotPeriodToSort[getParam('hot_period')] || getParam('sort');

  const clearAllFilters = () => {
    router.push('/phim');
  };

  const releaseStatus = getParam('release_status');
  const inCinema = getParam('in_cinema');
  const hotPeriod = getParam('hot_period');
  const hasActiveFilters =
    !!getParam('kind') || !!getParam('category') || !!getParam('country') || !!getParam('format') || !!getParam('year') || !!releaseStatus || !!inCinema || !!hotPeriod;

  const yearOptions: OptionItem[] = [
    { value: '', label: 'Tất cả' },
    ...Array.from({ length: 20 }, (_, i) => {
      const y = new Date().getFullYear() - i;
      return { value: String(y), label: String(y) };
    }),
  ];

  const sortOptions: OptionItem[] = SORT_OPTIONS.map((o) => ({ value: o.value, label: o.label }));

  return (
    <div className="relative z-10 mb-6 rounded-xl border border-gray-200 dark:border-gray-700/80 bg-white dark:bg-gray-800/50 shadow-sm overflow-visible">
      <div className="p-4 space-y-4">
        {/* Row 1: Quick filters (pills) + Sort */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-8">
            <div className="flex flex-col gap-2">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Trạng thái</span>
              <div className="flex flex-wrap gap-2">
                {RELEASE_OPTIONS.map((o) => (
                  <FilterChip
                    key={o.value}
                    active={releaseStatus === o.value}
                    onClick={() => handleFilterChange('release_status', o.value)}
                  >
                    {o.label}
                  </FilterChip>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Chiếu rạp</span>
              <div className="flex flex-wrap gap-2">
                {CINEMA_OPTIONS.map((o) => (
                  <FilterChip
                    key={o.value}
                    active={inCinema === o.value}
                    onClick={() => handleFilterChange('in_cinema', o.value)}
                  >
                    {o.label}
                  </FilterChip>
                ))}
              </div>
            </div>
            {/* Toggle bộ lọc chi tiết nằm cạnh Chiếu rạp */}
            <div className="flex flex-col gap-2 justify-end">
              <button
                type="button"
                onClick={() => setExpanded(!expanded)}
                className="flex items-center gap-2 text-sm font-medium text-blue-600 dark:text-blue-600 hover:text-blue-600 h-9 px-3 rounded-lg border border-dashed border-blue-300 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
              >
                <SlidersHorizontal className={`w-4 h-4 transition-transform ${expanded ? 'rotate-90' : ''}`} />
                {expanded ? 'Ẩn bộ lọc' : 'Bộ lọc nâng cao'}
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:min-w-[160px] sm:shrink-0">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1">
              <ArrowDownAZ className="w-3.5 h-3.5" />
              Sắp xếp
            </span>
            <SelectFilter
              id="sort"
              label=""
              value={sortValue}
              onChange={handleSortChange}
              options={sortOptions}
            />
          </div>
        </div>

        {/* Row 2: Extended filters - collapsible on mobile */}
        <div className="pt-3 border-t border-gray-100 dark:border-gray-700/60">
          <div className={`grid grid-cols-2 sm:grid-cols-4 gap-4 ${expanded ? '' : 'hidden'}`}>
            <SelectFilter
              id="kind"
              label="Kiểu phim"
              value={getParam('kind')}
              onChange={(v) => handleFilterChange('kind', v)}
              optionList={kinds}
            />
            <SelectFilter
              id="category"
              label="Thể loại"
              value={getParam('category')}
              onChange={(v) => handleFilterChange('category', v)}
              optionList={categories}
            />
            <SelectFilter
              id="country"
              label="Quốc gia"
              value={getParam('country')}
              onChange={(v) => handleFilterChange('country', v)}
              optionList={countries}
            />
            <SelectFilter
              id="year"
              label="Năm"
              value={getParam('year')}
              onChange={(v) => handleFilterChange('year', v)}
              options={yearOptions}
            />
          </div>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={clearAllFilters}
              className="mt-3 flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
              Xóa bộ lọc
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
