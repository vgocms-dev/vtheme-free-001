'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';
import { Clapperboard, ChevronLeft, ChevronRight } from 'lucide-react';

function getThumbUrl(video: VideoItem) {
  return getImageUrl(video.thumb || video.poster);
}

export default function CinemaSlider({ videos }: { videos: VideoItem[] }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [slideOffset, setSlideOffset] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);

  const activeVideo = videos[activeIndex] || videos[0];
  const CARD_GAP = 16;
  const CARD_WIDTH = 150;

  const computeOffsetForCenter = useCallback(
    (index: number, vWidth: number) => {
      const viewportW = vWidth || 300;
      const maxOff = Math.max(0, (videos.length - 1) * (CARD_WIDTH + CARD_GAP) + CARD_WIDTH - viewportW);
      const target = index * (CARD_WIDTH + CARD_GAP) + CARD_WIDTH / 2 - viewportW / 2;
      return Math.max(0, Math.min(target, maxOff));
    },
    [videos.length]
  );

  const goPrev = useCallback(() => {
    const next = activeIndex > 0 ? activeIndex - 1 : videos.length - 1;
    setActiveIndex(next);
    setSlideOffset(computeOffsetForCenter(next, viewportWidth));
  }, [activeIndex, videos.length, computeOffsetForCenter, viewportWidth]);

  const goNext = useCallback(() => {
    const next = activeIndex < videos.length - 1 ? activeIndex + 1 : 0;
    setActiveIndex(next);
    setSlideOffset(computeOffsetForCenter(next, viewportWidth));
  }, [activeIndex, videos.length, computeOffsetForCenter, viewportWidth]);

  useEffect(() => {
    if (!sliderRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setViewportWidth(entry.contentRect.width);
      }
    });
    observer.observe(sliderRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    setSlideOffset(computeOffsetForCenter(activeIndex, viewportWidth));
  }, [activeIndex, viewportWidth, computeOffsetForCenter]);

  useEffect(() => {
    const interval = setInterval(goNext, 5000);
    return () => clearInterval(interval);
  }, [goNext]);

  if (!videos.length) return null;

  return (
    <div className="flex gap-0 rounded-xl overflow-hidden bg-gray-900/50 dark:bg-gray-900/80 border border-amber-500/20">
      {/* Left: Slider with 2 cards */}
      <div
        ref={sliderRef}
        className="relative flex-1 md:flex-shrink-0 w-full md:w-[calc(150px*2+16px+56px)] overflow-hidden min-h-[225px] flex items-center"
      >
        <div className="absolute inset-y-0 left-0 z-10 w-8 bg-gradient-to-r from-gray-900/90 to-transparent flex items-center justify-start">
          <button
            type="button"
            onClick={goPrev}
            className="p-1.5 rounded-full bg-white/10 hover:bg-amber-500/50 text-amber-200 transition-colors"
            aria-label="Trước"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
        <div
          className="flex items-center gap-4 p-4 transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${slideOffset}px)` }}
        >
          {videos.map((v, i) => {
            const isActive = i === activeIndex;
            const cardClass = `block flex-shrink-0 transition-all duration-300 rounded-lg overflow-hidden border-2 ${isActive
              ? 'border-amber-400 scale-110 shadow-xl shadow-amber-500/20 z-10'
              : 'border-amber-500/30 hover:border-amber-500/60 scale-[0.92] opacity-85'
              }`;
            return (
              <Link
                key={v.id}
                href={`/phim/${v.slug}`}
                onClick={(e) => {
                  if (viewportWidth >= 768) {
                    e.preventDefault();
                    setActiveIndex(i);
                    setSlideOffset(computeOffsetForCenter(i, viewportWidth));
                  }
                }}
                className={cardClass}
                style={{ width: CARD_WIDTH }}
              >
                <div className="relative aspect-[2/3]">
                  <Image
                    src={getImageUrl(v.poster || v.thumb)}
                    alt={v.title}
                    fill
                    sizes="150px"
                    quality={75}
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                  <div className="absolute top-1.5 left-1.5">
                  </div>
                  <div className="absolute bottom-1.5 left-1.5 right-1.5">
                    <span className="text-white text-xs font-semibold line-clamp-2">{v.title}</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
        {/* Gradient đen bên phải mờ dần sang trái - bắt đầu từ mép ảnh thumb */}
        <div className="absolute inset-y-0 right-0 z-10 w-24 sm:w-32 bg-gradient-to-l from-black via-black/60 to-transparent pointer-events-none" />
        <div className="absolute inset-y-0 right-0 z-20 w-12 flex items-center justify-end pr-1">
          <button
            type="button"
            onClick={goNext}
            className="p-1.5 rounded-full bg-white/10 hover:bg-amber-500/50 text-amber-200 transition-colors pointer-events-auto"
            aria-label="Sau"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Right: Featured video - thumb làm nền + chi tiết (ẩn trên mobile) */}
      <Link
        href={`/phim/${activeVideo.slug}`}
        className="hidden md:flex relative flex-1 min-w-0 gap-4 p-4 hover:opacity-95 transition-opacity overflow-hidden"
      >
        <Image
          src={getThumbUrl(activeVideo)}
          alt=""
          fill
          priority
          fetchPriority="high"
          quality={60}
          className="object-cover object-center"
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/80 to-black/60" />
        <div className="relative z-10 flex gap-4 flex-1 min-w-0">
          <div className="relative flex-shrink-0 w-36 sm:w-44 aspect-[2/3] rounded-lg overflow-hidden border-2 border-amber-500/40">
            <Image
              src={getImageUrl(activeVideo.poster || activeVideo.thumb)}
              alt={activeVideo.title}
              fill
              sizes="(max-width: 640px) 288px, 352px"
              priority
              fetchPriority="high"
              quality={80}
              className="object-cover"
            />
          </div>
          <div className="flex-1 min-w-0 flex flex-col justify-center py-2">
            <h3 className="text-lg sm:text-xl font-bold text-white line-clamp-2">
              {activeVideo.title}
              {activeVideo.year > 0 && (
                <span className="text-amber-400 font-normal text-base ml-1">({activeVideo.year})</span>
              )}
            </h3>
            {activeVideo.original_name && (
              <p className="text-amber-200/80 text-sm mt-1 line-clamp-1">{activeVideo.original_name}</p>
            )}
            <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2 text-xs text-gray-300">
              {activeVideo.kind && (
                <span className="text-amber-400">{activeVideo.kind.lang_name || activeVideo.kind.name}</span>
              )}
              {activeVideo.countries && activeVideo.countries.length > 0 && (
                <span>{activeVideo.countries.map((c) => c.lang_name || c.name).join(', ')}</span>
              )}
              {activeVideo.categories && activeVideo.categories.length > 0 && (
                <span>{activeVideo.categories.map((c) => c.lang_name || c.name).join(', ')}</span>
              )}
            </div>
            <div className="flex items-center text-amber-200/70 text-xs mt-3">
              <svg className="w-4 h-4 mr-1.5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                <path
                  fillRule="evenodd"
                  d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z"
                  clipRule="evenodd"
                />
              </svg>
              {activeVideo.views?.toLocaleString() || 0} lượt xem
            </div>
            <span className="inline-flex items-center gap-2 mt-4 text-amber-400 text-sm font-medium">
              Xem ngay
              <ChevronRight className="w-4 h-4" />
            </span>
          </div>
        </div>
      </Link>
    </div>
  );
}
