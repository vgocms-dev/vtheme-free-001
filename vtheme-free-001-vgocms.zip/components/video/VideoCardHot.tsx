import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';

export default function VideoCardHot({ video, rank, priority }: { video: VideoItem; rank: number; priority?: boolean }) {
  const imgSrc = getImageUrl(video.poster || video.thumb);

  const formats = video.formats || [];
  const formatLabels = formats.slice(0, 2).map((f) => f.lang_name || f.name);
  const isCompleted = video.release_status === 'completed';
  const episodeInfo =
    (video.episode_count ?? 0) > 0
      ? isCompleted
        ? `Tập (${video.current_episode ?? 0}/${video.episode_count ?? 0})`
        : `Tập ${video.current_episode ?? video.episode_count ?? 0}`
      : `FULL`;

  return (
    <Link
      href={`/phim/${video.slug}`}
      className="group block rounded-lg overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:opacity-95 bg-transparent"
    >
      {/* Poster - clean, minimal overlay */}
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-lg bg-gray-800">
        <Image
          src={imgSrc}
          alt={video.title}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, (max-width: 1536px) 20vw, 15vw"
          quality={75}
          priority={priority}
          fetchPriority={priority ? "high" : undefined}
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Gradient nhẹ phía dưới cho đọc tag */}
        <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black/70 to-transparent" />
        {/* Tags HD (xám), Vietsub (xanh) - bottom left như ảnh */}
        <div className="absolute bottom-2 left-2 flex flex-wrap gap-1.5">
          {formatLabels.length > 0 ? (
            formatLabels.map((label) => (
              <span
                key={label}
                className="bg-emerald-700 text-white text-[10px] font-medium px-2 py-0.5 rounded shadow-sm"
              >
                {label}
              </span>
            ))
          ) : (
            <span className="bg-emerald-700 text-white text-[10px] font-medium px-2 py-0.5 rounded shadow-sm">
              Vietsub
            </span>
          )}
        </div>
      </div>

      {/* Text section - rank trái, name phải */}
      <div className="pt-2.5 px-0.5 flex gap-2 items-start">
        {/* Số thứ tự - trái ngoài */}
        <div className="text-5xl font-black text-amber-800 dark:text-amber-500 leading-none flex-shrink-0 drop-shadow-sm">
          {rank}
        </div>
        {/* Name bên phải */}
        <div className="min-w-0 flex-1">
          <h3 className="text-gray-900 dark:text-white font-bold text-sm leading-snug line-clamp-2">
            {video.title}
          </h3>
          {episodeInfo && (
            <p className="text-gray-700 dark:text-gray-400 text-[11px] mt-1 font-medium">
              {episodeInfo}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}
