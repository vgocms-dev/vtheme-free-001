'use client';

import { useEffect, useState, useRef } from 'react';

export default function AdSlot({ position, ads }: { position: string; ads: any[] }) {
  const [adHtml, setAdHtml] = useState<string>('');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    // Find active ad for this position
    if (!ads || !Array.isArray(ads)) return;
    
    const activeAd = ads.find(ad => ad.position === position && ad.is_active);
    if (activeAd && activeAd.content) {
      setAdHtml(activeAd.content);
    }
  }, [position, ads]);

  useEffect(() => {
    if (adHtml && iframeRef.current) {
      const doc = iframeRef.current.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <style>
                body { margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; overflow: hidden; background: transparent; }
                img { max-width: 100%; height: auto; }
              </style>
            </head>
            <body>${adHtml}</body>
          </html>
        `);
        doc.close();
      }
    }
  }, [adHtml]);

  if (!adHtml) return null;

  return (
    <div className={`ad-slot ad-${position} w-full flex justify-center text-center overflow-hidden bg-transparent my-4`}>
      <iframe
        ref={iframeRef}
        title={`Ad ${position}`}
        sandbox="allow-scripts allow-popups allow-forms allow-same-origin"
        className="w-full border-none min-h-[90px] bg-transparent flex justify-center text-center"
        scrolling="no"
      />
    </div>
  );
}
