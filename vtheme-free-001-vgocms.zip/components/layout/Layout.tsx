import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getSiteSettings, getSiteMenu, getSiteAds } from '@/lib/api';
import { getImageUrl } from '@/lib/utils';
import { MENU_HEADER_SLUG, MENU_FOOTER_SLUG } from '@/lib/config';
import NavMenu from '@/components/layout/NavMenu';
import MobileMenu from '@/components/layout/MobileMenu';
import MenuIcon from '@/components/layout/MenuIcon';
import AdSlot from '@/components/layout/AdSlot';
import SearchInput from '@/components/layout/SearchInput';

export async function Header() {
  const [settingsRes, menuRes, adsRes] = await Promise.all([
    getSiteSettings().catch(() => ({ success: false, data: null })),
    getSiteMenu(MENU_HEADER_SLUG).catch(() => null),
    getSiteAds().catch(() => []),
  ]);

  const settings = settingsRes.success ? settingsRes.data : null;
  const menuItems = menuRes && menuRes.items ? menuRes.items : [];


  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-50">
      <div className="max-w-[1800px] mx-auto px-3 sm:px-4 lg:px-5">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <MobileMenu items={menuItems} />
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center gap-2">
                {settings?.logo_url ? (
                  <div className="relative h-8 w-32">
                    <Image
                      src={getImageUrl(settings.logo_url)}
                      alt={settings.name || 'Logo'}
                      fill
                      className="object-contain object-left"
                      sizes="128px"
                    />
                  </div>
                ) : (
                  <span className="text-xl font-bold">{settings?.name || 'My Site'}</span>
                )}
              </Link>
            </div>
          </div>

          <div className="hidden md:flex">
            <NavMenu items={menuItems} />
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <SearchInput />
            </div>
          </div>
        </div>
      </div>
      <div>
        {/* Chỉ hiển thị Header banner ở đây nếu muốn nằm trên Navbar */}
        <AdSlot position="header_banner" ads={ads} />
      </div>
    </header>
  );
}

export async function Footer() {
  const [settingsRes, menuRes, adsRes] = await Promise.all([
    getSiteSettings().catch(() => ({ success: false, data: null })),
    getSiteMenu(MENU_FOOTER_SLUG).catch(() => null),
    getSiteAds().catch(() => []),
  ]);

  const settings = settingsRes.success ? settingsRes.data : null;
  const menuItems = menuRes && menuRes.items ? menuRes.items : [];
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  return (
    <footer className="bg-gray-100 dark:bg-gray-800 mt-10">
      <div>
        <AdSlot position="footer_banner" ads={ads} />
      </div>

      <div className="container mx-auto px-4 pb-8 mt-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            {settings?.logo_url ? (
              <div className="relative h-10 w-40 mb-4">
                <Image
                  src={getImageUrl(settings.logo_url)}
                  alt={settings.name || 'Logo'}
                  fill
                  className="object-contain object-left"
                  sizes="160px"
                />
              </div>
            ) : (
              <h3 className="text-xl font-bold mb-4">{settings?.name || 'My Site'}</h3>
            )}
            <p className="text-gray-700 dark:text-gray-300 text-sm">
              {settings?.description || 'Website giải trí trực tuyến.'}
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-gray-800 dark:text-white">Liên kết hữu ích</h4>
            <div className="flex flex-col gap-2 text-gray-700 dark:text-gray-300">
              {menuItems.map(item => (
                <Link key={item.id} href={item.url} target={item.target === '_blank' ? '_blank' : undefined} className="flex items-center gap-2 hover:text-blue-500 transition-colors">
                  <MenuIcon name={item.icon} className="w-4 h-4 flex-shrink-0 opacity-70" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-gray-800 dark:text-white">Từ khóa tìm kiếm</h4>
            <div className="flex flex-wrap gap-2 text-gray-600 dark:text-gray-300 text-sm">
              {settings?.seo_keywords?.split(',').map((keyword, i) => (
                <span key={i} className="bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded-sm">
                  {keyword.trim()}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700 text-center text-gray-600 dark:text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} {settings?.name || 'My Site'}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
