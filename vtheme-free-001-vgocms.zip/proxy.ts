import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function proxy(request: NextRequest) {
  const response = NextResponse.next();
  const { pathname } = request.nextUrl;

  const varyParts = [
    'RSC',
    'Next-Router-State-Tree',
    'Next-Router-Prefetch',
    'Accept-Encoding',
    'Next-Url',
  ];
  response.headers.set('Vary', varyParts.join(', '));

  if (pathname.startsWith('/api/')) {
    response.headers.set(
      'Cache-Control',
      'private, no-store, no-cache, must-revalidate, max-age=0'
    );
  } else {
    response.headers.set(
      'Cache-Control',
      'private, no-cache, must-revalidate, max-age=0'
    );
  }

  response.headers.set('X-DNS-Prefetch-Control', 'off');

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon\\.ico).*)',
  ],
};
